---
name: Clinical Emerald EMR
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3e4943'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6e7a73'
  outline-variant: '#bdc9c1'
  surface-tint: '#006c4e'
  primary: '#005d42'
  on-primary: '#ffffff'
  primary-container: '#047857'
  on-primary-container: '#9ffdd3'
  inverse-primary: '#7bd8b1'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#005b53'
  on-tertiary: '#ffffff'
  tertiary-container: '#00766c'
  on-tertiary-container: '#90fced'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#97f5cc'
  primary-fixed-dim: '#7bd8b1'
  on-primary-fixed: '#002115'
  on-primary-fixed-variant: '#00513a'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#89f5e7'
  tertiary-fixed-dim: '#6bd8cb'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#005049'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
  caption:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies the precision, trust, and calm authority required of high-stakes clinical and Electronic Medical Record (EMR) environments. It fuses modern clinical SaaS ergonomics with an editorial, refined emerald-and-jade palette, departing from the ubiquitous, fatigued hospital-blue aesthetic.

The design movement is **Modern Minimalist with Precision Elevation**:
- Utilitarian efficiency designed to reduce cognitive fatigue during long diagnostic sessions and EHR data entry.
- Razor-sharp structural clarity using delicate micro-borders, atmospheric pale slate surfaces, and intentional jade accents.
- Calm, authoritative visual hierarchy that instills immediate trust in practitioners, nursing staff, and clinical administrators.
- High data density balanced by disciplined rhythm, generous optical breathing room within modular cards, and unambiguous status indicators.

## Colors

The palette centers on therapeutic green and slate undertones, balancing rigorous compliance legibility with contemporary visual craft.

### Palette Architecture
- **Primary (`#047857` / `#059669`)**: Deep clinical emerald. Serves as the primary anchor for core actions, persistent navigation states, primary buttons, and selected tabs.
- **Secondary (`#10b981` / `#34d399`)**: Vibrant mint and jade. Reserved for active interactive accents, progress indications, metrics highlights, and subtle hover glows.
- **Tertiary (`#0d9488`)**: Deep sea teal. Utilized for secondary analytical categories, telemetry tags, and differential diagnostic flags.
- **Neutral (`#64748b`)**: Balanced slate gray. Controls typography scales, structural micro-borders, and neutral component surfaces.

### Surfaces & Backgrounds
- **Canvas Base**: `#f8fafc` layered over a faint, warm emerald mist (`#f0fdf4` at 35% opacity), eliminating screen glare without appearing warm or muddy.
- **Surface Elevation 1 (Cards & Workspaces)**: `#ffffff` with absolute optical crispness.
- **Surface Elevation 2 (Sidebars & Sub-panels)**: `#f8fafc` paired with `#e2e8f0` structural dividing lines.
- **Surface Muted / Inactive**: `#f1f5f9`.

### Clinical Status & Triage Semantics
- **Emergency / Critical**: Crimson alert (`#dc2626` base, `#fef2f2` container tint, `#991b1b` text).
- **Urgent / Warning**: Amber triaging (`#d97706` base, `#fffbeb` container tint, `#92400e` text).
- **Stable / Verified (Success)**: Clinical emerald (`#059669` base, `#ecfdf5` container tint, `#065f46` text).
- **Informational / Observation**: Cerulean slate (`#0284c7` base, `#f0f9ff` container tint, `#075985` text).

## Typography

Typography relies on **Inter** configured with OpenType tabular figures (`tnum`) and slashed zeros for numerical integrity across patient vitals, dosages, and lab analytics.

### Hierarchy & Legibility
- **Display & Section Titles (`headline-xl`, `headline-lg`)**: Tight tracking, strong weights (`600` / `700`) to anchor dense patient summary views and multi-pane clinical layouts.
- **Card & Section Headers (`headline-md`, `headline-sm`)**: High contrast (`#0f172a`), creating instant structural landmarks across dense clinical dashboards.
- **Clinical Data & Body (`body-md`, `body-sm`)**: Neutral balance (`#334155`) with high legibility at glance speed.
- **Labels & Badges (`label-md`, `label-sm`, `caption`)**: Elevated font-weight (`600`) with uppercase conversion where appropriate for triage categories, blood gas data, and dosage schedules.

## Layout & Spacing

The layout is built around a **12-column adaptive fluid workbench**, engineered for both high-density clinical workstation displays (1440px–2560px) and point-of-care mobile tablets (768px–1024px).

### Layout Blueprint
- **Desktop (1280px+)**: A three-pane split layout comprising an expandable collapsed mini-rail nav (64px to 240px), a patient demographic/encounter pinned sidebar (320px), and an 8-column main EMR workspace with a persistent 1.25rem (`gutter`) flow.
- **Tablet / Mobile Bedside (768px - 1023px)**: Condenses into a master-detail sheet layout. The clinical encounter navigation docks into a persistent bottom bar; patient vitals collapse into a swipeable horizontal card carousel.
- **Handheld Point-of-Care (<768px)**: Single column with edge-to-edge content cards bounded by a 1rem margin, prioritizing immediate action buttons (medication administration, code triage).

### Density Philosophy
- Standard padding adheres to an 8pt base grid (`space-xs: 4px`, `space-sm: 8px`, `space-md: 12px`, `space-lg: 20px`, `space-xl: 32px`).
- Form elements and vital rows utilize compact vertical padding (`space-sm`) to maximize above-the-fold information visibility, preventing unnecessary scrolling during critical assessments.

## Elevation & Depth

This system avoids heavy, distracting dropshadows, deploying instead **ambient emerald-tinted diffusion** alongside crisp structural micro-borders.

### Layering Model
1. **Canvas (Base Level 0)**: Background `#f8fafc` with neutral slate foundation.
2. **Structural Bordering**: All containers feature a hairline 1px micro-border (`#e2e8f0` or light mint `#e6f4ea`), giving absolute boundary definition under ambient light.
3. **Card Resting Elevation (Level 1)**: Pure white `#ffffff` cards supported by a subtle dual-shadow:
   `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 2px 6px -1px rgba(4, 120, 87, 0.03)`.
4. **Interactive Hover / Focus Elevation (Level 2)**: Cards, active rows, and popovers elevate cleanly with an increased green-tinted halo:
   `0 4px 12px -2px rgba(15, 23, 42, 0.06), 0 2px 6px -1px rgba(4, 120, 87, 0.08)`.
5. **Modal / Diagnostic Drawer (Level 3)**: Deep floating layer for medication reconciliation modals and slide-out laboratory logs:
   `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(4, 120, 87, 0.06)`, framed by a crisp 1px `#cbd5e1` micro-border.

## Shapes

The design uses a **Controlled Rounded (Level 2)** geometry:
- **Base Geometry (`rounded-lg`, 8px to 10px)**: Primary building block for data cards, input fields, dropdown menus, and diagnostic containers. Provides a modern, humanized feel while preserving structural rigidity.
- **Pill Radius (`rounded-full`, 9999px)**: Strictly reserved for patient status badges, triage pills, telemetry chips, and primary floating action buttons (FABs).
- **Sub-elements (`rounded-md`, 6px)**: Checkboxes, segmented switch pills, and compact table tags to avoid visual ballooning inside high-density charts.

## Components

### Buttons
- **Primary**: Rich emerald fill (`#047857`) transitioning to `#065f46` on hover, white text (`#ffffff`), 10px border radius, subtle inner highlight `inset 0 1px 0 rgba(255, 255, 255, 0.15)`.
- **Secondary / Outline**: Clean white background, 1px border in `#cbd5e1`, slate text (`#1e293b`). On hover: border shifts to `#059669`, background shifts to `#f0fdf4`.
- **Destructive / Alert**: `#dc2626` solid fill for emergency orders, or 1px `#fca5a5` outline with `#991b1b` text for soft warnings.

### Status Badges & Triage Chips
- **Geometry**: True pill shape (`rounded-full`), `py-0.5 px-2.5`, text size `label-sm` (11px, `600` weight).
- **Emergency**: Container `#fef2f2`, border `#fecaca`, text `#991b1b`, with a pulsating 6px crimson dot indicator.
- **Warning / Review**: Container `#fffbeb`, border `#fde68a`, text `#92400e`.
- **Normal / Verified**: Container `#ecfdf5`, border `#a7f3d0`, text `#065f46`.
- **Observation / Routine**: Container `#f1f5f9`, border `#e2e8f0`, text `#475569`.

### Input Fields & Controls
- **Form Controls**: Minimum 38px height, 8px radius, white surface, framed by a 1px micro-border in `#cbd5e1`.
- **Focus State**: Non-spreading 1px emerald border (`#059669`) backed by a 3px diffused outer ring (`rgba(16, 185, 129, 0.2)`).
- **Checkboxes & Radios**: 16px square or circular toggles. Unchecked: `#e2e8f0` border with white core. Checked: `#047857` solid fill featuring a crisp optical white checkmark icon.

### Cards & Encounters Modules
- **Structure**: Surface `#ffffff`, border 1px solid `#e2e8f0`, radius 10px, padding `1.25rem`.
- **Header Separator**: Hairline divider `#f1f5f9` between the card title bar and data body.
- **Active / Focused Encounter Card**: Border transitions to `#10b981` (50% opacity) with a faint background ambient shadow tinted in emerald.

### Specialized Clinical Elements
- **Vitals Metric Tile**: Single quantitative metric display with tabular figure formatting, subtle mini-sparkline track (mint `#34d399`), and micro-indicators for trending direction (up/down delta glyphs).
- **Patient Banner / Sticky Header**: Persistent 56px top ribbon showing patient avatar, MRN (Medical Record Number), age/sex, allergy warnings in high-contrast red pill badges, and active attending physician details.