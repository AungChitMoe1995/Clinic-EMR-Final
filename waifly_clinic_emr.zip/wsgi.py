import os
from run import app

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=25516, debug=True, threaded=True)
