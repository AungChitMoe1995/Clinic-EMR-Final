# Waifly Deployment Guide - Myanmar Clinic EMR

### Quick Start on Waifly
1. **Upload & Extract:**
   - Upload `waifly_clinic_emr.zip` to your Waifly document root / application directory.
   - Extract the contents.

2. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Start Application:**
   - **Direct Python command:**
     ```bash
     python run.py
     ```
     Starts on `http://0.0.0.0:25516` in debug mode as configured.

   - **cPanel / CloudLinux Python Selector (Passenger WSGI):**
     - Application startup file: `passenger_wsgi.py` (or `run.py`)
     - Application Entry point: `application` (or `app`)

   - **Gunicorn:**
     ```bash
     gunicorn -w 2 -b 0.0.0.0:25516 run:app
     ```

4. **Database:**
   - Pre-configured to automatically connect to Waifly MariaDB:
     - **Host:** `db.waifly.com:3306`
     - **Database:** `s10258_clinic_emr`
     - **User:** `u10258_wOmSdH3una`
   - Default login account:
     - **Phone:** `09123456789`
     - **Password:** `password123`
